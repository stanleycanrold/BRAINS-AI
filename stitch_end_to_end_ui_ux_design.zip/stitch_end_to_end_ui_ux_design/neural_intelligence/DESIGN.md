---
name: Neural Intelligence
colors:
  surface: '#faf8ff'
  surface-dim: '#d9d9e5'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f3fe'
  surface-container: '#ededf9'
  surface-container-high: '#e7e7f3'
  surface-container-highest: '#e1e2ed'
  on-surface: '#191b23'
  on-surface-variant: '#434655'
  inverse-surface: '#2e3039'
  inverse-on-surface: '#f0f0fb'
  outline: '#737686'
  outline-variant: '#c3c6d7'
  surface-tint: '#0053db'
  primary: '#004ac6'
  on-primary: '#ffffff'
  primary-container: '#2563eb'
  on-primary-container: '#eeefff'
  inverse-primary: '#b4c5ff'
  secondary: '#565e74'
  on-secondary: '#ffffff'
  secondary-container: '#dae2fd'
  on-secondary-container: '#5c647a'
  tertiary: '#943700'
  on-tertiary: '#ffffff'
  tertiary-container: '#bc4800'
  on-tertiary-container: '#ffede6'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dbe1ff'
  primary-fixed-dim: '#b4c5ff'
  on-primary-fixed: '#00174b'
  on-primary-fixed-variant: '#003ea8'
  secondary-fixed: '#dae2fd'
  secondary-fixed-dim: '#bec6e0'
  on-secondary-fixed: '#131b2e'
  on-secondary-fixed-variant: '#3f465c'
  tertiary-fixed: '#ffdbcd'
  tertiary-fixed-dim: '#ffb596'
  on-tertiary-fixed: '#360f00'
  on-tertiary-fixed-variant: '#7d2d00'
  background: '#faf8ff'
  on-background: '#191b23'
  surface-variant: '#e1e2ed'
  status-passed: '#10B981'
  status-rethink: '#F59E0B'
  status-killed: '#EF4444'
  surface-subtle: '#F8FAFC'
  border-muted: '#E2E8F0'
typography:
  display-score:
    fontFamily: Hanken Grotesk
    fontSize: 72px
    fontWeight: '700'
    lineHeight: 80px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Hanken Grotesk
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
  headline-md:
    fontFamily: Hanken Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-mono:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.05em
  headline-lg-mobile:
    fontFamily: Hanken Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  container-max: 1280px
  gutter: 1.5rem
  margin-mobile: 1rem
  stack-sm: 0.5rem
  stack-md: 1rem
  stack-lg: 2rem
---

## Brand & Style

The design system embodies **Precision-Engineering** for the founder's workspace. It is built to project authority, analytical depth, and unwavering reliability. The personality is that of a "High-Level Intelligence Analyst"—calm, data-driven, and transparent.

The aesthetic follows a **Corporate / Modern** style with a focus on **Data-Centric Minimalism**. It avoids decorative fluff in favor of "wireframe" transparency and structural clarity. The interface acts as a visual parser for complex JSON data, ensuring that every AI-generated insight is traceable to its source. 

Key attributes include:
- **Traceability:** Every claim is backed by a link or raw data point.
- **Agency:** The UI empowers the human-in-the-loop to accept, reject, or edit AI proposals.
- **Efficiency:** A technical, focused environment that prioritizes information density and logical flow.

## Colors

The palette is anchored by **Intelligence Blue**, a vibrant yet professional primary color used for interactive elements and brand identifiers. 

- **Primary Blue (#2563EB):** Used for primary actions, active navigation states, and the brand "B".
- **Deep Slate (#0F172A):** Used for primary headings and high-contrast text to ensure authority.
- **Semantic Signals:** A strict traffic-light system manages validation states: Green for "Passed," Amber for "Rethink," and Red for "Killed."
- **Neutral Backgrounds:** The workspace uses a crisp white base with subtle slate-gray surfaces (#F8FAFC) to differentiate between research cards and the main application background.

## Typography

Typography prioritizes sharp legibility and a technical feel. 

- **Hanken Grotesk** provides a modern, sharp geometric feel for headlines and high-level metrics.
- **Inter** is utilized for body text and long-form research reports, selected for its exceptional readability in data-heavy contexts.
- **JetBrains Mono** is reserved for "System Metadata"—labels, badges, niche-expert tags, and JSON data references. This reinforces the "intelligence analyst" aesthetic.

For validation scores, a massive **Display Score** style is used to provide an immediate, undeniable focal point upon screen entry.

## Layout & Spacing

This design system utilizes a **Fixed Grid** for dashboard views and a **Linear Pipeline** for wizard-style workflows.

- **The Pipeline:** For the initial 5-step process, a focused, single-column layout (max-width 800px) is used to minimize distraction.
- **The Dashboard:** The Decision Gate and Founder's Report screens utilize a 12-column grid.
- **Vertical Rhythm:** A strict 8px-based spacing system governs the vertical flow. "Proposed changes" are presented as a stack of cards with 1rem (`stack-md`) gaps to indicate they are individual entities.
- **Mobile Reflow:** On mobile, side-by-side comparison tables (e.g., Normal vs. Fast Track) reflow into a vertical stacked format with a toggle-based comparison.

## Elevation & Depth

In alignment with its "Precision-Engineering" philosophy, the design system uses **Tonal Layers** and **Low-Contrast Outlines** rather than heavy shadows.

- **Surfaces:** Depth is achieved by placing cards (#FFFFFF) on a slightly tinted background (#F8FAFC). 
- **Borders:** Containers use a 1px border (#E2E8F0). When a card is "AI-Proposed" but not yet accepted, it may use a dashed border or a subtle blue tint.
- **Transparency:** Borrowing from the logo's aesthetic, "network" visualizations and secondary data nodes use 60-70% opacity to establish hierarchy without adding visual weight.

## Shapes

The shape language is **Soft** but disciplined. 

- **Corners:** A 0.25rem (4px) base radius is applied to buttons, input fields, and cards. This provides a professional edge that feels modern but not overly playful.
- **Pills:** Status badges (e.g., `draft`, `passed`) use a fully rounded "pill" shape to distinguish them from functional UI components.
- **Iconography:** Icons follow the logo's "neural" style—geometric, using 0.55pt stroke weights and round line-caps to balance technical precision with approachability.

## Components

- **Validation Cards:** The core component. These cards feature a header with a "Signal Badge," a plain-language summary, and a footer containing source links. AI-generated cards include "Accept/Reject/Edit" action buttons in the bottom right.
- **Status Badges:** Compact labels using **JetBrains Mono**. Color-coded based on the semantic palette (e.g., a green pill for "Passed").
- **Decision Gate Slider:** A high-impact visual representation of the 0–100 score, typically located at the top of report screens.
- **Response Log Tables:** Highly structured, dense tables with monospaced text for data values, utilizing subtle zebra-striping for readability.
- **Action Buttons:**
    - *Primary:* Solid Blue (#2563EB) with white text.
    - *Secondary:* Outline (Blue border) or Ghost (Grey text) for "Accept/Reject" loops.
- **Input Fields:** Large, free-text areas that encourage "paragraph-style" input, using a 1px slate border that thickens and turns blue on focus.