# BRAINS AI — Versioning & Rework Logic

## 1. Versioning Architecture
- Every 'Rework' action creates a new `idea_state_version`.
- The `parent_version_id` links it back to the previous iteration.
- All reports (Research, Validation, Decision) are tied to specific version IDs.

## 2. The Rework Loop
- Triggered from the Decision Gate.
- User selects 'Rework Idea'.
- System prompts user to 'Accept Changes' from the Decision Agent's improvement proposal.
- Accepted changes are patched into the new version's `structured` fields.
- User chooses to re-run Step 2 (Research) or skip to Step 3 (Validation).

## 3. Timeline UI Requirements
- Visual branch visualization if multiple rifts occur.
- Difference highlighting (Diff view) for Problem Statement, ICP, and Value Prop.
- Centralized 'Learning Log'—a summary of what was invalidated in previous versions to avoid repetitive mistakes.
